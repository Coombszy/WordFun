﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Globalization;

public class ClientHandler
{
    private int MyID = 0;
    private NetworkStream DataStream;
    public bool InLobby = false;
    bool IAmActive = true;//ClientHandler Activity State
    string ClientUserName = "NAME";
    public int TimeOutTime;
    private DateTime TimeStamp;
    public ClientHandler(int Id)
    {
        MyID = Id;
    }
    public TcpClient ClientSocket;//creates a public TcpClient Variable
    public TcpClient MySocket
    {
        get { return ClientSocket; }//returns my socket
    }
    public void StartClient(TcpClient ClientSocketToParse)
    {
        this.ClientSocket = ClientSocketToParse;
        Thread ClientThread = new Thread(LobbyInteraction);
        TimeStamp = DateTime.Now;
        ClientThread.Start();
    }//Function that starts the client on a new thread and parses it a socket
    public void WriteLine(string ToWrite)
    {
        Console.WriteLine("[{0}] " + ToWrite, DateTime.Now);
    }
    public void Disconnect()
    {
        GameServerHandler.TimeOutCheck();
        ClientSocket.Close();
        DataStream.Close();
        Console.WriteLine(" >> ClientID:" + MyID + " -" + ClientUserName + "- Disconnected");
        GameServerHandler.RemoveClient(MyID);
        InLobby = false;
    }
    public void LobbyInteraction()
    {
        string IncomingMessage;
        Send("" + MyID);
        ClientUserName = Listen();
        while (IAmActive)
        {
            try
            {
                IncomingMessage = Listen();
                /*
                if (!(IncomingMessage == ""))
                {
                    Console.WriteLine("id:" + MyID + " msg:" + IncomingMessage);
                }
                */
                if (IncomingMessage == "/DISCONNECT")
                {
                    Disconnect();   
                    break;
                }//Must be first to prevent getting locked in a loop with other states
                if (IncomingMessage == "/INLOBBY")
                {
                    if (!InLobby)
                    {
                        InLobby = true;
                    }
                    else
                    {
                        InLobby = false;
                    }
                }
                if (InLobby == true)
                {
                    if(!(IncomingMessage == "") && !(IncomingMessage =="/INLOBBY"))
                    {
                        WriteLine(@"ClientID:"+MyID+" Transmitted '"+IncomingMessage+"'.");
                        GameServerHandler.SendToAll(IncomingMessage);
                        GameServerHandler.TimeOutCheck();
                        GameServerHandler.ClientsInLobbyCheck();
                    }
                }
            }
            catch (Exception Error)
            {
                Console.WriteLine(" >> ClientError - ClientID:" + MyID + " - " + Error.ToString()  );//.Substring(0, Error.ToString().IndexOf("at System")));
                ClientSocket.Dispose();
                GameServerHandler.RemoveClient(MyID);
                Console.WriteLine(" >> ClientError - Corrected! ClientID " + MyID + "'s Disconnect was Handled and the Clients Session was Removed Successfully");
            }
        }
    }
    public void Send(string ToSend)
    {
        NetworkStream ServerStream = ClientSocket.GetStream();
        string data = ToSend;
        byte[] outStream = System.Text.Encoding.ASCII.GetBytes(data + "$");
        ServerStream.Write(outStream, 0, outStream.Length);
        ServerStream.Flush();
    }
    public string ListenAndWait()
    {
        byte[] BytesReceived = new byte[1280];
        string DataReceived = null;
        while (true)
        {
            try
            {
                DataStream = ClientSocket.GetStream();
                DataStream.Read(BytesReceived, 0, BytesReceived.Length);
                DataReceived = System.Text.Encoding.ASCII.GetString(BytesReceived);
                DataReceived = DataReceived.Substring(0, DataReceived.IndexOf("$"));
                break;
            }
            catch { }
        }
        return DataReceived;
    }
    public string Listen()
    {
        byte[] BytesReceived = new byte[1280];
        string DataReceived = null;
        while (true)
        {
            try
            {
                DataStream = ClientSocket.GetStream();
                if (DataStream.DataAvailable)
                {
                    DataStream.Read(BytesReceived, 0, BytesReceived.Length);
                    DataReceived = System.Text.Encoding.ASCII.GetString(BytesReceived);
                    DataReceived = DataReceived.Substring(0, DataReceived.IndexOf("$"));
                    DataStream.Flush();
                }
                else { DataReceived = ""; }
                break;
            }
            catch
            {
                DataReceived = "";
                break;
            }
        }
        return DataReceived;
    }
    public bool TimeOutCheck()
    {
        var Difference = (DateTime.Now - TimeStamp).TotalSeconds;
        if (Difference >= TimeOutTime)
        {
            TimeStamp = DateTime.Now;
            Send("/AREYOUTHERE");
            string Reply = ListenAndWait();
            if (!(Reply == "/IMHERE") && !(Reply=="/INLOBBY"))
            {
                Console.WriteLine(" >> ClientError - ClientID:" + MyID + " - Client has TimedOut!");
                ClientSocket.Dispose();
                GameServerHandler.RemoveClient(MyID);
                Console.WriteLine(" >> ClientError - Corrected! ClientID:" + MyID + " - Client Session has be Terminated Successfully");
                return false;
            }
            return true;
        }
        return true;
    }
}
