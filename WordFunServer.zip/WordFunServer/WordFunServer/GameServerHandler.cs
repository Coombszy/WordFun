﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Globalization;


public class GameServerHandler
{
    private TcpListener ServerSocket;
    private TcpClient ClientSocket;
    private static int ConnectedClients = 0;
    private static int TimeOut;
    private static int LobbySize;
    private static object[] ClientArray;
    private static bool AllClientsInLobby = false;
    public void WriteLine(string ToWrite)
    {
        Console.WriteLine("[{0}] " + ToWrite, DateTime.Now);
    }
    public static void StaticWriteLine(string ToWrite)
    {
        Console.WriteLine("[{0}] " + ToWrite, DateTime.Now);
    }
    public GameServerHandler(int Port, int LobbySize_, int ServerTimeOut)
    {
        LobbySize = LobbySize_;
        ClientArray = new object[LobbySize];
        ServerSocket = new TcpListener(IPAddress.Any, Port);
        TimeOut = ServerTimeOut;
        ServerSocket.Start();
        Console.WriteLine(" >> Server Started!");
        Console.WriteLine(" >> Listening for Clients");
        while (!(AllClientsInLobby))
        {
            if(AllClientsInLobby == true)
            {
                break;
            }
            int ClientID = HandleClientId();
            try
            {
                if (ServerSocket.Pending())
                {
                    ClientSocket = ServerSocket.AcceptTcpClient();
                    Console.WriteLine(" >> " + "Client With ID -" + Convert.ToString(ClientID) + "- has Connected ({0}/{1} Clients Connected)", ConnectedClients + 1, LobbySize);
                    ClientHandler Client = new ClientHandler(ClientID);
                    Client.StartClient(ClientSocket);
                    Client.TimeOutTime = TimeOut;
                    ClientArray[ClientID] = Client;
                    ConnectedClients++;
                }
            }
            catch
            {
                Console.WriteLine("CATCH STATEMENT");
                Console.WriteLine("Connected Clients:"+ConnectedClients);
            }
        }
        Console.WriteLine(" >> Start conditions met! Game starting!");
        InGame();
    }
    public void InGame()
    {
        SendToAll("/GAMESTART");
    }
    public static void ClientsInLobbyCheck()
    {
        int flags = 0;
        try
        {
            if (!(ClientArray[0] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[0];
                if (Client.InLobby == false)
                {
                    flags++;
                }
            }
        }
        catch { Console.WriteLine("Catch!"); }
        try
        {
            if (!(ClientArray[1] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[1];
                if (Client.InLobby == false)
                {
                    flags++;
                }
            }
        }
        catch { Console.WriteLine("Catch!"); }
        try
        {
            if (!(ClientArray[2] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[2];
                if (Client.InLobby == false)
                {
                    flags++;
                }
            }
        }
        catch { Console.WriteLine("Catch!"); }
        try
        {
            if (!(ClientArray[3] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[3];
                if (Client.InLobby == false)
                {
                    flags++;
                }
            }
        }
        catch { Console.WriteLine("Catch!"); }
        if (ConnectedClients < LobbySize)
        {
            flags++;
        }
        if (flags == 0)
        {
            AllClientsInLobby = true;
        }
        else
        {
            AllClientsInLobby = false;
        }
    }
    public static void RemoveClient(int Id)
    {
        ClientArray[Id] = null;
        ConnectedClients--;
    }
    public static void RemoveAllClients()
    {
        for(int i =0; i < ClientArray.Count(); i++)
        {
            try
            {
                ClientHandler Client = (ClientHandler)ClientArray[i];
                Client.ClientSocket.Dispose();
                ClientArray[i] = null;
            }
            catch{}
        }
        ConnectedClients = 0;
    }
    public static int HandleClientId()
    {
        if(ClientArray[0] == null)
        {
            return 0;
        }
        else if (ClientArray[1] == null)
        {
            return 1;
        }
        else if (ClientArray[2] == null)
        {
            return 2;
        }
        else
        {
            return 3;
        }
    }
    public static bool TimeOutCheck()
    {
        int flags = 0;
        try
        {
            if (!(ClientArray[0] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[0];
                if (Client.TimeOutCheck())
                {
                    flags++;
                }
            }
        }catch{ }
        try
        {
            if (!(ClientArray[1] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[1];
                if (Client.TimeOutCheck())
                {
                    flags++;
                }
            }
        }catch { }
        try
        {
            if (!(ClientArray[2] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[2];
                if (Client.TimeOutCheck())
                {
                    flags++;
                }
            }
        } catch { }
        try
        {
            if (!(ClientArray[3] == null))
            {
                ClientHandler Client = (ClientHandler)ClientArray[3];
                if (Client.TimeOutCheck())
                {
                    flags++;
                }
            }
        }catch { }
        if (flags == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public static void SendToAll(string ToSend)
    {
        for(int i = 0; i < ClientArray.Count(); i++)
        {
            try
            {
                ClientHandler Client = (ClientHandler)ClientArray[i];
                Client.Send(ToSend);
            }
            catch { }
        }
    }
}

