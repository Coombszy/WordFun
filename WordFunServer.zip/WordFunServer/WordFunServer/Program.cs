﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WordFunServer
{
    public class Program
    {
        static public int TimeOutTime = 0;
        static void Main(string[] args)
        {
            string Line;//Defines the Line String
            int ServerListenPort = 0;//Port for the server, to be loaded from the config
            int GameLobbySize = 0;//
            try
            {
                StreamReader ConfigFile = new StreamReader("cfg/Config.txt");//creates a streamreader of the config file
                while ((Line = ConfigFile.ReadLine()) != null)
                {
                    if (Line.StartsWith("port="))
                    {
                        ServerListenPort = int.Parse(Line.Substring(5));//gets the port number stored in the line
                    }//If a line starts with port=
                    if (Line.StartsWith("lobbysize="))
                    {
                        GameLobbySize = int.Parse(Line.Substring(10));//gets the lobbysize number stored in the line
                    }//If a line starts with lobbysize=
                    if (Line.StartsWith("timeout="))
                    {
                        TimeOutTime = int.Parse(Line.Substring(8));//gets the lobbysize number stored in the line
                    }//If a line starts with lobbysize=
                }//for each line that contains data do this
            }
            catch
            {
                Console.WriteLine(" >> Config Failed to Load!");
                Console.WriteLine(" >> Press Enter to Exit ");
                Console.ReadLine();
                Environment.Exit(0);
            }
            Console.WriteLine(" >> Config Loaded!");
            Console.WriteLine("port="+ServerListenPort);
            Console.WriteLine("lobbysize=" + GameLobbySize);
            Console.WriteLine("timeout=" + TimeOutTime);
            GameServerHandler Game = new GameServerHandler(ServerListenPort, GameLobbySize, TimeOutTime);
            Console.WriteLine(" >> Server Closed - Press enter to close");
            Console.ReadLine();
        }
    }
}
