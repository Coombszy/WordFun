﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;

public class ClientHandler
{
    public TcpClient ClientSocket;//creates a public TcpClient Variable
    public TcpClient MySocket
	{
        get { return ClientSocket; }//returns my socket
	}
    bool IAmActive = true;//ClientHandler Activity State
    string ClientUserName = "NAME";
    public void StartClient(TcpClient ClientSocketToParse)
    {
        this.ClientSocket = ClientSocketToParse;
        Thread ClientThread = new Thread(Interact);
        ClientThread.Start();
    }//Function that starts the client on a new thread and parses it a socket
    public void Interact()
    {
        byte[] BytesReceived = new byte[1280];
        string DataRecieved = null;
        while(IAmActive)
        {
            try
            {
                NetworkStream DataStream = clientSocket.GetStream();
                DataStream.Read(BytesReceived, 0, BytesReceived.Length);
                DataRecieved = System.Text.Encoding.ASCII.GetString(BytesReceived);
                dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"));
                if (dataFromClient == "/DISCONNECT")
                {
                    ClientSocket.Close();
                    DataStream.Close();
                    Console.WriteLine(" >> Client -" + ClientUserName + "- Disconnected");
                    break;
                }
            }
            catch (Exception Error)
            {
                Console.WriteLine(" >>  ClientError - "+ClientUserName+" - " + Error.ToString());
            }
        }

    }
}
